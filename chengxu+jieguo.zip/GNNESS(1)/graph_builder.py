import numpy as np

import torch

from torch_geometric.data import Data

from tqdm import tqdm



def extract_node_features(a_i, i, d, a):

    eps = 1e-12

    norm = np.linalg.norm(a) + eps

    normalized = a_i / norm

    position = i / d

    log_magnitude = np.log(1 + abs(normalized))

    

    

    return [normalized, position, log_magnitude]



def deduplicate_and_weight_weighted(edges, weights, local_weight=1.0):

    edge_dict = {}

    

    

    for edge, weight in zip(edges, weights):

        if edge not in edge_dict:

            edge_dict[edge] = 0

        edge_dict[edge] += weight

        

    unique_edges = list(edge_dict.keys())

    final_weights = list(edge_dict.values())

    

    if final_weights:

        max_weight = max(final_weights)

        normalized_weights = [w / max_weight for w in final_weights]

    else:

        normalized_weights = []

        

    return unique_edges, final_weights, normalized_weights



def build_hankel_edges(d, R_max, delta=6):

    

    edge_dict = {}

    

    n_coeff = d + 1

    

    

    max_window_size = min(20, 2 * R_max + 1)

    

    for r in range(1, R_max + 1):

        Lr = min(2 * r + 1, max_window_size)

        

        if Lr > n_coeff:

            continue

        

        for s in range(n_coeff - Lr + 1):

            window = list(range(s, s + Lr))

            

            for idx1 in range(len(window)):

                for idx2 in range(idx1 + 1, len(window)): 

                    i = window[idx1]

                    j = window[idx2]

                    

                    

                    

                    

                    

                    

                    

                    

                    

                    

                    

                    if abs(i - j) <= delta:

                        edge = (i, j)

                        if edge not in edge_dict:

                            edge_dict[edge] = 0

                        edge_dict[edge] += 1

    

    

    edges = []

    weights = []

    for edge, count in edge_dict.items():

        edges.append(edge)

        weights.append(count)

    

    

    reverse_edges = []

    reverse_weights = []

    for edge, weight in zip(edges, weights):

        reverse_edges.append((edge[1], edge[0]))

        reverse_weights.append(weight)

    edges.extend(reverse_edges)

    weights.extend(reverse_weights)

    

    

    if weights:

        max_weight = max(weights)

        normalized_weights = [w / max_weight for w in weights]

    else:

        normalized_weights = []

    

    return edges, weights, normalized_weights



def build_local_edges(d):

    edges = []

    

    for i in range(d):

        edges.append((i, i + 1))

        edges.append((i + 1, i))

    return edges



def build_coefficient_graph(a, d, R_max=10, delta=6):

    node_features = []

    for i in range(len(a)):

        features = extract_node_features(a[i], i, d, a)

        node_features.append(features)

    x = torch.tensor(node_features, dtype=torch.float32)

    

    

    local_edges = build_local_edges(d)

    

    

    

    local_weights = [1.0] * len(local_edges)

    

    

    hankel_edges, hankel_weights, _ = build_hankel_edges(d, R_max, delta)

    

    

    all_edges = local_edges + hankel_edges

    all_raw_weights = local_weights + hankel_weights

    

    unique_edges, all_weights, normalized_all_weights = deduplicate_and_weight_weighted(all_edges, all_raw_weights)

    

    edge_index = torch.tensor(unique_edges, dtype=torch.long).t().contiguous()

    edge_weights = torch.tensor(normalized_all_weights, dtype=torch.float32)

    

    data = Data(x=x, edge_index=edge_index, edge_attr=edge_weights)

    return data



def build_batch_graphs(dataset, R_max=10, delta=6, normalize_features=True, stats=None):

    graphs = []

    

    

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    print(f"Using device {device} for feature statistics calculation")



    

    if normalize_features and stats is None:

        

        feature_chunks = []

        chunk_size = 10000

        current_chunk = []

        

        for i, sample in enumerate(tqdm(dataset, desc="Collecting features for normalization")):

            a = sample['a']

            d = sample['d']

            graph = build_coefficient_graph(a, d, R_max, delta)

            current_chunk.append(graph.x)

            

            if len(current_chunk) >= chunk_size:

                feature_chunks.append(torch.cat(current_chunk, dim=0))

                current_chunk = []

        

        if current_chunk:

            feature_chunks.append(torch.cat(current_chunk, dim=0))

            

        

        

        total_sum = torch.zeros(3, device=device)

        total_sq_sum = torch.zeros(3, device=device)

        total_count = 0

        

        for chunk in tqdm(feature_chunks, desc="Computing stats on GPU"):

            chunk_gpu = chunk.to(device)

            total_sum += chunk_gpu.sum(dim=0)

            total_sq_sum += (chunk_gpu ** 2).sum(dim=0)

            total_count += chunk.size(0)

            del chunk_gpu

        

        mean = (total_sum / total_count).cpu()

        

        var = (total_sq_sum / total_count) - mean.to(device) ** 2

        std = torch.sqrt(var).cpu() + 1e-12

        

        stats = (mean, std)

        

        

        del feature_chunks

        if torch.cuda.is_available():

            torch.cuda.empty_cache()

    

    

    for sample in tqdm(dataset, desc="Building graphs"):

        a = sample['a']

        d = sample['d']

        graph = build_coefficient_graph(a, d, R_max, delta)

        

        

        if normalize_features and stats is not None:

            mean, std = stats

            graph.x = (graph.x - mean) / std

        

        graph.y_rank = torch.tensor([sample['true_rank'] - 1], dtype=torch.long)

        noise_level = float(sample['noise_level'])

        

        

        

        roots = sample.get('roots', [])

        min_spacing = 1.0  

        if len(roots) > 1:

            roots_complex = [complex(r) if not isinstance(r, (int, float, complex)) else r for r in roots]

            min_dist = float('inf')

            for i in range(len(roots_complex)):

                for j in range(i + 1, len(roots_complex)):

                    dist = abs(roots_complex[i] - roots_complex[j])

                    if dist < min_dist:

                        min_dist = dist

            min_spacing = min_dist

            

        

        

        is_stable = (min_spacing >= 1e-3) and (noise_level <= 1e-3)

        

        graph.y_stability = torch.tensor([1.0 if is_stable else 0.0], dtype=torch.float32)

        graphs.append(graph)

    

    return graphs, stats
