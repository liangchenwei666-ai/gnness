import yaml

import os

import sys

import torch

import time





sys.path.append(os.path.dirname(os.path.abspath(__file__)))



from evaluate import evaluate_all_methods, evaluate_by_degree



def load_config(config_path):

    with open(config_path, 'r') as f:

        config = yaml.safe_load(f)

    return config



def main():

    print("Loading configuration for evaluation...")

    config_path = 'config.yaml'

    if not os.path.exists(config_path):

        print(f"Error: {config_path} not found.")

        return



    config = load_config(config_path)



    

    config['training']['model_save_path'] = './models/rank_gnn_paper.pth'

    

    

    config['model']['R_max'] = 10

    config['solver']['tau'] = 1e-3 

    

    

    if not os.path.exists(config['training']['model_save_path']):

        print(f"Error: Model file {config['training']['model_save_path']} not found. Run training first.")

        return



    

    config['data']['test_samples'] = 3000



    print("\n--- Starting Evaluation ---")

    try:

        

        print("\nEvaluating All Methods...")

        evaluate_all_methods(config)

        

        

        print("\nEvaluating By Degree...")

        evaluate_by_degree(config)

        

        print("Evaluation completed successfully.")

    except Exception as e:

        print(f"Evaluation failed: {e}")

        import traceback

        traceback.print_exc()



if __name__ == '__main__':

    main()

